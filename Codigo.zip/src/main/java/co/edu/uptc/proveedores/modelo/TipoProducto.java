package co.edu.uptc.proveedores.modelo;

/**
 *
 * @author fredy
 */
public class TipoProducto {
    
}
